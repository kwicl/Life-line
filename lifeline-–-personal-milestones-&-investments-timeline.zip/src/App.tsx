/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';
import Timeline from './components/Timeline';

export default function App() {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleMilestoneAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-cosmic-black overflow-hidden selection:bg-electric-blue/30">
      <TopBar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar onMilestoneAdded={handleMilestoneAdded} />
        <Timeline key={refreshKey} />
      </div>
    </div>
  );
}

